META_switch 1.1.0 — variable mappings

Extract this whole folder. Keep META_switch.amxd and meta_switch.js together.
Drag META_switch.amxd onto a MIDI track in Ableton Live (Max for Live required).
Set Mappings to 1–32; the default is 8. Hidden assignments are retained.
The device width follows the mapping count.

This is an unfrozen development build. Automated routing and structural
checks pass; visual behavior, Live save/reload and MIDI hardware still need
host validation. Open the Max project to export/freeze with Max if desired.
Source and verification instructions: https://github.com/AdrianArtacho/META_switch
